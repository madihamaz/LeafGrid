"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _inheritsLoose;
var _setPrototypeOf = require("./setPrototypeOf.js");
function _inheritsLoose(subClass, superClass) {
  subClass.prototype = Object.create(superClass.prototype);
  subClass.prototype.constructor = subClass;
  (0, _setPrototypeOf.default)(subClass, superClass);
}

//# sourceMappingURL=inheritsLoose.js.map
