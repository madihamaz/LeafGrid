"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _AwaitValue;
function _AwaitValue(value) {
  this.wrapped = value;
}

//# sourceMappingURL=AwaitValue.js.map
