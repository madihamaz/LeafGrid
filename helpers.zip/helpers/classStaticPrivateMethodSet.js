"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _classStaticPrivateMethodSet;
function _classStaticPrivateMethodSet() {
  throw new TypeError("attempted to set read only static private field");
}

//# sourceMappingURL=classStaticPrivateMethodSet.js.map
