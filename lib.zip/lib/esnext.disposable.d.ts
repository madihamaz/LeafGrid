import type { ImplicitLibVariableOptions } from '../variable';
export declare const esnext_disposable: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.disposable.d.ts.map