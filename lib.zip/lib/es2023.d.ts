import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2023: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2023.d.ts.map