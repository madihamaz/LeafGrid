import type { ImplicitLibVariableOptions } from '../variable';
export declare const es7: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es7.d.ts.map