import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2017_date: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2017.date.d.ts.map