import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2019_full: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2019.full.d.ts.map