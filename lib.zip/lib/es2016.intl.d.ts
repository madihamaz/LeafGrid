import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2016_intl: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2016.intl.d.ts.map