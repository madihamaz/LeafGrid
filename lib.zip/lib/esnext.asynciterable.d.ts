import type { ImplicitLibVariableOptions } from '../variable';
export declare const esnext_asynciterable: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.asynciterable.d.ts.map