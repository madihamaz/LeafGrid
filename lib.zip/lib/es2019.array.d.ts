import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2019_array: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2019.array.d.ts.map