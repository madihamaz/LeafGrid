import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2018: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2018.d.ts.map