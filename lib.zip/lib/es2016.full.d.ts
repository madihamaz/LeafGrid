import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2016_full: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2016.full.d.ts.map