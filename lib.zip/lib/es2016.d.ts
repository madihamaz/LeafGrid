import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2016: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2016.d.ts.map