import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2015_symbol_wellknown: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2015.symbol.wellknown.d.ts.map