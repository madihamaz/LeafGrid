import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2022_regexp: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2022.regexp.d.ts.map