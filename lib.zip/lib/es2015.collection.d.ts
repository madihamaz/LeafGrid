import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2015_collection: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2015.collection.d.ts.map