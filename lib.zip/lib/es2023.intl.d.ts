import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2023_intl: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2023.intl.d.ts.map