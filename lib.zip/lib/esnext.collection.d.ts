import type { ImplicitLibVariableOptions } from '../variable';
export declare const esnext_collection: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.collection.d.ts.map