import type { ImplicitLibVariableOptions } from '../variable';
export declare const dom_iterable: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=dom.iterable.d.ts.map