import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2023_array: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2023.array.d.ts.map