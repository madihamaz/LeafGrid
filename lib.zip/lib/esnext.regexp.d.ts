import type { ImplicitLibVariableOptions } from '../variable';
export declare const esnext_regexp: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.regexp.d.ts.map