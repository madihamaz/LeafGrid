import type { ImplicitLibVariableOptions } from '../variable';
export declare const esnext_object: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.object.d.ts.map