import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2020_string: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2020.string.d.ts.map