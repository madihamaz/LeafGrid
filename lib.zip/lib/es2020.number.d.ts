import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2020_number: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2020.number.d.ts.map