import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2023_full: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2023.full.d.ts.map