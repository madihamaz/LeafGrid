import type { ImplicitLibVariableOptions } from '../variable';
export declare const esnext: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.d.ts.map