import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2020: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2020.d.ts.map