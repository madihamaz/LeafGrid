import type { ImplicitLibVariableOptions } from '../variable';
export declare const dom_asynciterable: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=dom.asynciterable.d.ts.map