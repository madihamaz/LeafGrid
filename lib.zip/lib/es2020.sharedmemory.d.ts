import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2020_sharedmemory: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2020.sharedmemory.d.ts.map