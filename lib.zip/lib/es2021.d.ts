import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2021: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2021.d.ts.map