import type { ImplicitLibVariableOptions } from '../variable';
export declare const esnext_intl: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.intl.d.ts.map