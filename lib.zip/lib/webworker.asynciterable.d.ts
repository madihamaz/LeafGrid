import type { ImplicitLibVariableOptions } from '../variable';
export declare const webworker_asynciterable: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=webworker.asynciterable.d.ts.map