import type { ImplicitLibVariableOptions } from '../variable';
export declare const esnext_decorators: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.decorators.d.ts.map